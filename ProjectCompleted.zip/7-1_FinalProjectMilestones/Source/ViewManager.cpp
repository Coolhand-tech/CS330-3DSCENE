#include "ViewManager.h"

// Include GLM for math operations
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// *** ADDED ***
// Global variables and constants in anonymous namespace for internal linkage
namespace
{
    // Window size
    const int WINDOW_WIDTH = 1000;
    const int WINDOW_HEIGHT = 800;

    // Shader uniform names
    const char* g_ViewName = "view";
    const char* g_ProjectionName = "projection";

    // Camera pointer
    Camera* g_pCamera = nullptr;

    // Mouse tracking variables for first mouse input and position
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Timing for frame delta calculations
    float gDeltaTime = 0.0f;
    float gLastFrame = 0.0f;

    // Flag to toggle projection type (perspective vs orthographic)
    bool bOrthographicProjection = false;
}

// Constructor - initialize members and camera
ViewManager::ViewManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_pWindow = NULL;

    // *** ADDED ***
    // Initialize the camera position and orientation
    g_pCamera = new Camera();
    g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
    g_pCamera->Yaw = -90.0f;
    g_pCamera->Pitch = -15.0f;
    g_pCamera->MovementSpeed = 3.0f;
    g_pCamera->MouseSensitivity = 0.1f;
    g_pCamera->Zoom = 45.0f;
}

// *** ADDED ***
// Create the GLFW window, set OpenGL context, and assign mouse callbacks
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
    GLFWwindow* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, windowTitle, NULL, NULL);
    if (!window)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return NULL;
    }
    glfwMakeContextCurrent(window);

    // Capture and hide the cursor for FPS-style mouse control
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // Set mouse movement callback
    glfwSetCursorPosCallback(window, Mouse_Position_Callback);

    // Set mouse scroll callback
    glfwSetScrollCallback(window, Mouse_Scroll_Callback);

    m_pWindow = window;

    return window;
}

// *** ADDED ***
// Mouse movement callback - update camera yaw and pitch based on mouse movement
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xPos, double yPos)
{
    if (gFirstMouse)
    {
        gLastX = (float)xPos;
        gLastY = (float)yPos;
        gFirstMouse = false;
    }

    float xoffset = (float)(xPos - gLastX);
    float yoffset = (float)(gLastY - yPos); // reversed: y ranges bottom to top

    gLastX = (float)xPos;
    gLastY = (float)yPos;

    if (g_pCamera)
        g_pCamera->ProcessMouseMovement(xoffset, yoffset);
}

// *** ADDED ***
// Mouse scroll callback - zoom or movement speed changes
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset)
{
    if (g_pCamera)
        g_pCamera->ProcessMouseScroll((float)yoffset);
}

// *** ADDED ***
// Check keyboard state every frame and update camera position and projection toggle
void ViewManager::ProcessKeyboardEvents()
{
    if (!m_pWindow)
        return;

    if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(m_pWindow, true);

    if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
    if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
        g_pCamera->ProcessKeyboard(UP, gDeltaTime);

    // Projection toggle keys
    if (glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS)
        bOrthographicProjection = false;
    if (glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS)
        bOrthographicProjection = true;
}

// *** ADDED ***
// Prepare the view and projection matrices and update shader uniforms each frame
void ViewManager::PrepareSceneView()
{
    float currentFrame = (float)glfwGetTime();
    gDeltaTime = currentFrame - gLastFrame;
    gLastFrame = currentFrame;

    ProcessKeyboardEvents();

    glm::mat4 view;
    glm::mat4 projection;

    if (bOrthographicProjection)
    {
        float scale = 7.0f;
        projection = glm::ortho(-scale * (float)WINDOW_WIDTH / WINDOW_HEIGHT,
            scale * (float)WINDOW_WIDTH / WINDOW_HEIGHT,
            -scale,
            scale,
            0.1f,
            100.0f);

        // Fixed camera position and target for orthographic view
        view = glm::lookAt(glm::vec3(0, 8, 10), glm::vec3(0, 0, 0), glm::vec3(0, 1, 0));
    }
    else
    {
        projection = glm::perspective(glm::radians(g_pCamera->Zoom), (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT, 0.1f, 100.0f);
        view = g_pCamera->GetViewMatrix();
    }

    if (m_pShaderManager)
    {
        m_pShaderManager->setMat4Value(g_ViewName, view);
        m_pShaderManager->setMat4Value(g_ProjectionName, projection);
        m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
    }
}
