#ifndef VIEWMANAGER_H
#define VIEWMANAGER_H

#include <iostream>
#include <GL/glew.h>
#include <GLFW/glfw3.h>

#include "ShaderManager.h"
#include "Camera.h"

// The ViewManager manages the 3D view setup and projection to 2D
class ViewManager
{
public:
    // Constructor
    ViewManager(ShaderManager* pShaderManager);

    // Destructor
    ~ViewManager() = default;

    // Creates the GLFW window and sets callbacks
    GLFWwindow* CreateDisplayWindow(const char* windowTitle); // *** ADDED ***

    // Prepares the view and projection matrices each frame
    void PrepareSceneView(); // *** ADDED ***

private:
    // GLFW callback for mouse movement - updates camera rotation
    static void Mouse_Position_Callback(GLFWwindow* window, double xPos, double yPos); // *** ADDED ***

    // GLFW callback for mouse scroll wheel - updates zoom or speed
    static void Mouse_Scroll_Callback(GLFWwindow* window, double xoffset, double yoffset); // *** ADDED ***

    // Checks for key presses and moves the camera accordingly
    void ProcessKeyboardEvents(); // *** ADDED ***

private:
    GLFWwindow* m_pWindow;
    ShaderManager* m_pShaderManager;
};

#endif
